# 🚧 AI-Based Cloud Framework for Automated Pothole Detection and Repair Estimation

![Python](https://img.shields.io/badge/Python-3.9+-blue.svg)
![Django](https://img.shields.io/badge/Django-4.x-green.svg)
![YOLOv8](https://img.shields.io/badge/YOLO-v8-red.svg)
![License](https://img.shields.io/badge/License-MIT-yellow.svg)

A deep learning-powered web application that automatically detects potholes from road images, estimates repair volume, and calculates cost — built as a mini project for B.E. (ECE), Chaitanya Bharathi Institute of Technology, Hyderabad.

---

## 📌 Project Overview

Traditional pothole inspection relies on slow, costly manual surveys. This system uses:
- **YOLOv8** for real-time pothole detection
- **Monocular Depth Estimation** for volume calculation
- **Django + Cloud** for scalable web-based access
- **Repair Cost Estimation** based on detected volume

### Sample Output
> Image: `input2.jpg` → **4 Potholes Detected** | Volume: `1.0018 m³` | Cost: `₹6,010.56`

---

## 🏗️ System Architecture

```
Input Image/Video
      ↓
Preprocessing (Resize, Normalize, Annotate)
      ↓
YOLO Detection Model
      ↓
Bounding Box + Depth Estimation
      ↓
Volume & Cost Calculation
      ↓
Web Dashboard (Django)
      ↓
Cloud Storage & Reporting
```

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Language | Python 3.9+ |
| Detection Model | YOLOv8 (Ultralytics) |
| Image Processing | OpenCV |
| Web Framework | Django 4.x |
| Frontend | HTML, CSS, Bootstrap 5 |
| Depth Estimation | MiDaS / custom monocular model |
| Database | SQLite (dev) / PostgreSQL (prod) |
| Annotation Tool | LabelImg / Roboflow |
| Training Framework | PyTorch |

---

## 📂 Project Structure

```
pothole_detection/
├── pothole_app/
│   ├── migrations/
│   ├── templates/
│   │   └── accounts/
│   │       ├── index.html
│   │       ├── detect.html
│   │       └── dashboard.html
│   ├── static/
│   │   └── accounts/
│   │       └── style.css
│   ├── admin.py
│   ├── apps.py
│   ├── models.py
│   ├── urls.py
│   └── views.py
├── pothole_detection/
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
├── datasets/
│   └── images/         # Place training images here
├── runs/
│   └── detect/
│       └── train2/
│           └── weights/
│               └── best.pt   # Trained model weights (download separately)
├── uploads/            # User-uploaded images (auto-created)
├── outputs/            # Detection result images (auto-created)
├── depth/              # Depth maps (auto-created)
├── train.py
├── detect.py
├── requirements.txt
├── manage.py
└── README.md
```

---

## ⚙️ Installation & Setup

### 1. Clone the Repository
```bash
git clone https://github.com/<your-username>/pothole-detection.git
cd pothole-detection
```

### 2. Create a Virtual Environment
```bash
python -m venv venv
source venv/bin/activate        # Linux/Mac
venv\Scripts\activate           # Windows
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Add Model Weights
Download or train the YOLO model and place `best.pt` at:
```
runs/detect/train2/weights/best.pt
```
See [Training](#-training-your-own-model) section below to train from scratch.

### 5. Apply Migrations & Run Server
```bash
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser   # optional, for admin panel
python manage.py runserver
```

### 6. Open in Browser
```
http://127.0.0.1:8000/
```

---

## 🔍 Usage

1. Navigate to `http://127.0.0.1:8000/detect/`
2. Upload one or more road images
3. Enter the location name
4. Click **Submit**
5. View detection results with:
   - Bounding boxes around potholes
   - Pothole count, total volume, and repair cost estimate

---

## 🧠 Training Your Own Model

```bash
# Prepare your dataset in YOLO format (use Roboflow or LabelImg for annotation)
# Place images in datasets/images/

python train.py
```

Training output will be saved to `runs/detect/train2/weights/best.pt`.

You can also use a pre-annotated pothole dataset from:
- [Roboflow Pothole Dataset](https://roboflow.com/browse/pothole)
- [Kaggle Road Pothole Dataset](https://www.kaggle.com/datasets)

---

## 📊 Results

| Metric | Value |
|--------|-------|
| Detection Model | YOLOv8 |
| Confidence Score (sample) | 0.87 |
| Potholes Detected (sample) | 4 |
| Estimated Volume (sample) | 1.0018 m³ |
| Estimated Cost (sample) | ₹6,010.56 |

The model performs well under varied lighting, shadows, and road textures.

---

## 🔮 Future Scope

- [ ] GPS integration for location-based pothole mapping
- [ ] Mobile app for on-the-go reporting
- [ ] Drone/vehicle-mounted camera integration
- [ ] IoT sensor fusion for improved depth accuracy
- [ ] Lightweight model for edge/embedded deployment

---

## 🌍 SDG Alignment

| SDG | Goal | Contribution |
|-----|------|-------------|
| SDG 9 | Industry, Innovation & Infrastructure | AI-powered infrastructure monitoring |
| SDG 11 | Sustainable Cities & Communities | Smarter, safer urban roads |
| SDG 3 | Good Health & Well-being | Reducing road accident risks |
| SDG 8 | Decent Work & Economic Growth | Optimizing maintenance costs |

---

## 👥 Team

| Name | Roll Number |
|------|------------|
| Anil Kumar | 160123735025 |
| MD. Nayeemoddin | 160123735045 |
| Shaik Danish | 160123735055 |

**Supervisor:** Dr. D. Krishna Reddy, Professor, Dept. of ECE, CBIT Hyderabad

---

## 📄 License

This project is licensed under the MIT License. See [LICENSE](LICENSE) for details.
