"""
train.py — Train a YOLOv8 model on your pothole dataset.

Usage:
    python train.py

Before running:
  1. Annotate your images using LabelImg or Roboflow in YOLO format.
  2. Organise the dataset as shown below (or update DATA_YAML to your path):

     datasets/
       pothole.yaml
       images/
         train/  *.jpg
         val/    *.jpg
       labels/
         train/  *.txt
         val/    *.txt

  3. Edit pothole.yaml:
       path: datasets
       train: images/train
       val:   images/val
       nc: 1
       names: ['pothole']
"""

from ultralytics import YOLO

# ── Configuration ──────────────────────────────────────────────────────────────
MODEL_BASE   = "yolov8n.pt"          # starting checkpoint (nano = fastest)
DATA_YAML    = "datasets/pothole.yaml"
EPOCHS       = 50
IMAGE_SIZE   = 640
BATCH_SIZE   = 16
PROJECT_DIR  = "runs/detect"
RUN_NAME     = "train2"
# ───────────────────────────────────────────────────────────────────────────────


def main():
    model = YOLO(MODEL_BASE)

    results = model.train(
        data=DATA_YAML,
        epochs=EPOCHS,
        imgsz=IMAGE_SIZE,
        batch=BATCH_SIZE,
        project=PROJECT_DIR,
        name=RUN_NAME,
        exist_ok=True,
        patience=15,          # early stopping
        save=True,
        device="0",           # use "cpu" if no GPU available
    )

    print("\n✅ Training complete!")
    print(f"   Best weights saved to: {PROJECT_DIR}/{RUN_NAME}/weights/best.pt")
    print(f"   mAP50: {results.results_dict.get('metrics/mAP50(B)', 'N/A')}")


if __name__ == "__main__":
    main()
