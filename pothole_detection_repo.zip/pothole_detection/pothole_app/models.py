from django.db import models


class PotholeReport(models.Model):
    location = models.CharField(max_length=255)
    pothole_count = models.IntegerField(default=0)
    total_volume = models.FloatField(default=0.0)
    total_cost = models.FloatField(default=0.0)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.location} — {self.pothole_count} potholes — ₹{self.total_cost:.2f} ({self.created_at.strftime('%d %b %Y')})"

    class Meta:
        ordering = ['-created_at']
        verbose_name = "Pothole Report"
        verbose_name_plural = "Pothole Reports"


class PotholeImage(models.Model):
    report = models.ForeignKey(
        PotholeReport,
        on_delete=models.CASCADE,
        related_name='images'
    )
    image = models.ImageField(upload_to='uploads/')
    output_image = models.ImageField(upload_to='outputs/', blank=True, null=True)
    depth_image = models.ImageField(upload_to='depth/', blank=True, null=True)
    pothole_count = models.IntegerField(default=0)
    volume = models.FloatField(default=0.0)
    cost = models.FloatField(default=0.0)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Image for {self.report.location} — {self.pothole_count} potholes"
