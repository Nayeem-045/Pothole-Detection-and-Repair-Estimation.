import os
import cv2
import numpy as np
from pathlib import Path
from django.shortcuts import render, get_object_or_404
from django.conf import settings
from .models import PotholeReport, PotholeImage

# ── lazy-load YOLO so the server starts even without model weights ──
_yolo_model = None


def get_model():
    global _yolo_model
    if _yolo_model is None:
        try:
            from ultralytics import YOLO
            model_path = settings.YOLO_MODEL_PATH
            if Path(model_path).exists():
                _yolo_model = YOLO(str(model_path))
            else:
                print(f"[WARNING] Model not found at {model_path}. Using placeholder.")
        except Exception as e:
            print(f"[ERROR] Could not load YOLO model: {e}")
    return _yolo_model


# ── depth estimation (MiDaS-style; falls back to bounding-box heuristic) ──
def estimate_depth(image_np, bbox):
    """
    Returns an approximate depth value (metres) for a detected bounding box.
    Falls back to a heuristic when a depth model is unavailable.
    """
    try:
        import torch
        midas = torch.hub.load("intel-isl/MiDaS", "MiDaS_small", trust_repo=True)
        midas.eval()
        transforms = torch.hub.load("intel-isl/MiDaS", "transforms", trust_repo=True)
        transform = transforms.small_transform

        img_rgb = cv2.cvtColor(image_np, cv2.COLOR_BGR2RGB)
        input_batch = transform(img_rgb)
        with torch.no_grad():
            prediction = midas(input_batch)
            prediction = torch.nn.functional.interpolate(
                prediction.unsqueeze(1),
                size=img_rgb.shape[:2],
                mode="bicubic",
                align_corners=False,
            ).squeeze()
        depth_map = prediction.numpy()

        x1, y1, x2, y2 = map(int, bbox)
        roi_depth = depth_map[y1:y2, x1:x2]
        avg_depth = float(np.mean(roi_depth)) / 1000.0  # normalise
        return max(avg_depth, 0.05)

    except Exception:
        # heuristic: larger bounding box ≈ deeper pothole
        x1, y1, x2, y2 = bbox
        area = (x2 - x1) * (y2 - y1)
        img_area = image_np.shape[0] * image_np.shape[1]
        ratio = area / img_area
        return max(0.05 + ratio * 2.0, 0.05)


def calculate_volume(bbox, depth, pixels_per_meter=500):
    """Estimate pothole volume (m³) from bounding box dimensions and depth."""
    x1, y1, x2, y2 = bbox
    width_px = x2 - x1
    height_px = y2 - y1
    width_m = width_px / pixels_per_meter
    height_m = height_px / pixels_per_meter
    area_m2 = width_m * height_m
    volume = area_m2 * depth
    return round(volume, 4)


def run_detection(image_path):
    """
    Run YOLO detection on image_path.
    Returns (annotated_image_np, list_of_detections).
    Each detection: {'bbox': (x1,y1,x2,y2), 'confidence': float,
                     'depth': float, 'volume': float, 'cost': float}
    """
    image = cv2.imread(str(image_path))
    if image is None:
        return None, []

    model = get_model()
    detections = []

    if model:
        results = model(image)
        cost_per_m3 = getattr(settings, 'REPAIR_COST_PER_M3', 6000)

        for result in results:
            for box in result.boxes:
                x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
                conf = float(box.conf[0])
                depth = estimate_depth(image, (x1, y1, x2, y2))
                volume = calculate_volume((x1, y1, x2, y2), depth)
                cost = round(volume * cost_per_m3, 2)

                detections.append({
                    'bbox': (x1, y1, x2, y2),
                    'confidence': round(conf, 2),
                    'depth': round(depth, 3),
                    'volume': volume,
                    'cost': cost,
                })

                # Draw bounding box
                cv2.rectangle(image, (x1, y1), (x2, y2), (0, 255, 0), 2)
                label = f"pothole {conf:.2f}"
                cv2.putText(image, label, (x1, y1 - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
    else:
        # Placeholder box when model weights are missing
        h, w = image.shape[:2]
        cv2.rectangle(image, (w // 4, h // 4), (3 * w // 4, 3 * h // 4), (0, 0, 255), 2)
        cv2.putText(image, "Model not loaded", (w // 4, h // 4 - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)

    return image, detections


# ── Django views ──────────────────────────────────────────────────────────────

def homepage(request):
    recent_reports = PotholeReport.objects.all()[:5]
    return render(request, "accounts/index.html", {'recent_reports': recent_reports})


def detect_view(request):
    if request.method == "POST":
        location = request.POST.get("location", "Unknown")
        files = request.FILES.getlist("images")

        if not files:
            return render(request, "accounts/detect.html", {
                "message": "No images uploaded. Please select at least one image.",
                "message_type": "danger",
            })

        report = PotholeReport.objects.create(location=location)
        total_potholes = 0
        total_volume = 0.0
        total_cost = 0.0
        processed_images = []

        for f in files:
            pothole_image = PotholeImage.objects.create(report=report, image=f)

            # Full filesystem path of the uploaded image
            input_path = pothole_image.image.path

            annotated, detections = run_detection(input_path)

            img_potholes = len(detections)
            img_volume = sum(d['volume'] for d in detections)
            img_cost = sum(d['cost'] for d in detections)

            total_potholes += img_potholes
            total_volume += img_volume
            total_cost += img_cost

            # Save annotated output image
            if annotated is not None:
                output_dir = Path(settings.MEDIA_ROOT) / 'outputs'
                output_dir.mkdir(parents=True, exist_ok=True)
                out_filename = f"out_{pothole_image.pk}_{f.name}"
                out_path = output_dir / out_filename
                cv2.imwrite(str(out_path), annotated)
                pothole_image.output_image = f"outputs/{out_filename}"

            pothole_image.pothole_count = img_potholes
            pothole_image.volume = round(img_volume, 4)
            pothole_image.cost = round(img_cost, 2)
            pothole_image.save()

            processed_images.append({
                'filename': f.name,
                'potholes': img_potholes,
                'volume': round(img_volume, 4),
                'cost': round(img_cost, 2),
                'output_url': pothole_image.output_image.url if pothole_image.output_image else None,
                'detections': detections,
            })

        # Update report totals
        report.pothole_count = total_potholes
        report.total_volume = round(total_volume, 4)
        report.total_cost = round(total_cost, 2)
        report.save()

        return render(request, "accounts/detect.html", {
            "message": "Detection complete!",
            "message_type": "success",
            "report": report,
            "processed_images": processed_images,
        })

    return render(request, "accounts/detect.html")


def dashboard_view(request):
    reports = PotholeReport.objects.all()
    total_potholes = sum(r.pothole_count for r in reports)
    total_cost = sum(r.total_cost for r in reports)
    return render(request, "accounts/dashboard.html", {
        'reports': reports,
        'total_potholes': total_potholes,
        'total_cost': round(total_cost, 2),
    })


def report_detail(request, pk):
    report = get_object_or_404(PotholeReport, pk=pk)
    return render(request, "accounts/report_detail.html", {'report': report})
