from django.contrib import admin
from .models import PotholeReport, PotholeImage


class PotholeImageInline(admin.TabularInline):
    model = PotholeImage
    extra = 0
    readonly_fields = ('pothole_count', 'volume', 'cost', 'uploaded_at')


@admin.register(PotholeReport)
class PotholeReportAdmin(admin.ModelAdmin):
    list_display = ('location', 'pothole_count', 'total_volume', 'total_cost', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('location',)
    inlines = [PotholeImageInline]


@admin.register(PotholeImage)
class PotholeImageAdmin(admin.ModelAdmin):
    list_display = ('report', 'pothole_count', 'volume', 'cost', 'uploaded_at')
    readonly_fields = ('uploaded_at',)
