from django.urls import path
from . import views

urlpatterns = [
    path('', views.homepage, name='homepage'),
    path('detect/', views.detect_view, name='detect'),
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('report/<int:pk>/', views.report_detail, name='report_detail'),
]
