from django.apps import AppConfig


class PotholeAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pothole_app'
