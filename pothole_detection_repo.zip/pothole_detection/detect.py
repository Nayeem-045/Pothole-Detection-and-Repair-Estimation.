"""
detect.py — Run pothole detection on images or a video from the command line.

Usage:
    python detect.py --source path/to/image.jpg
    python detect.py --source path/to/video.mp4
    python detect.py --source datasets/images/val/
"""

import argparse
import cv2
import os
from pathlib import Path
from ultralytics import YOLO

MODEL_PATH   = "runs/detect/train2/weights/best.pt"
COST_PER_M3  = 6000     # INR per cubic metre
PPM          = 500       # pixels per metre (calibrate for your camera)


def estimate_volume(bbox, depth=0.1):
    x1, y1, x2, y2 = bbox
    w_m = (x2 - x1) / PPM
    h_m = (y2 - y1) / PPM
    return round(w_m * h_m * depth, 4)


def run(source: str, conf_thresh: float = 0.4, save_dir: str = "outputs/"):
    model = YOLO(MODEL_PATH)
    Path(save_dir).mkdir(parents=True, exist_ok=True)

    is_video = source.lower().endswith(('.mp4', '.avi', '.mov'))
    sources = [source] if is_video or Path(source).is_file() else \
              sorted(Path(source).glob("*.jpg")) + sorted(Path(source).glob("*.png"))

    for src in sources:
        src = str(src)
        cap = cv2.VideoCapture(src) if is_video else None
        frames = [cv2.imread(src)] if not is_video else []

        if is_video:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                frames.append(frame)
            cap.release()

        for idx, frame in enumerate(frames):
            results = model(frame, conf=conf_thresh)
            potholes, total_vol, total_cost = 0, 0.0, 0.0

            for result in results:
                for box in result.boxes:
                    x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
                    conf = float(box.conf[0])
                    vol  = estimate_volume((x1, y1, x2, y2))
                    cost = round(vol * COST_PER_M3, 2)

                    potholes   += 1
                    total_vol  += vol
                    total_cost += cost

                    cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                    cv2.putText(frame, f"pothole {conf:.2f}", (x1, y1 - 8),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

            summary = f"Potholes: {potholes}  Vol: {round(total_vol,4)} m3  Cost: Rs{round(total_cost,2)}"
            cv2.putText(frame, summary, (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 200, 255), 2)
            print(f"[{Path(src).name} frame {idx}] {summary}")

            out_path = os.path.join(save_dir, f"out_{Path(src).stem}_{idx}.jpg")
            cv2.imwrite(out_path, frame)

    print(f"\nResults saved to: {save_dir}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Pothole Detector")
    parser.add_argument("--source",     required=True, help="Image / video path or folder")
    parser.add_argument("--conf",       type=float, default=0.4, help="Confidence threshold")
    parser.add_argument("--save-dir",   default="outputs/", help="Output directory")
    args = parser.parse_args()
    run(args.source, args.conf, args.save_dir)
